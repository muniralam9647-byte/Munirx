package com.munirx.app

import android.app.Activity
import android.os.Bundle
import android.graphics.Color
import android.graphics.Typeface
import android.view.Gravity
import android.view.View
import android.widget.*
import java.security.MessageDigest
import java.security.SecureRandom

class MainActivity : Activity() {
    private val prefs by lazy { getSharedPreferences("munirx_auth", MODE_PRIVATE) }
    private val bg = Color.rgb(9, 13, 24)
    private val red = Color.rgb(255, 48, 68)
    private val blue = Color.rgb(37, 139, 255)
    private lateinit var root: LinearLayout

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        showEntry()
    }

    private fun shell(): LinearLayout {
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(28, 28, 28, 28)
            setBackgroundColor(bg)
        }
        setContentView(root)
        return root
    }

    private fun heading(subtitle: String) {
        addText(root, "MUNIR X", 34f, red, true, 0, 2)
        addText(root, subtitle, 13f, blue, true, 0, 26)
    }

    private fun addText(parent: LinearLayout, value: String, size: Float, color: Int,
                        bold: Boolean = false, top: Int = 8, bottom: Int = 8) {
        val t = TextView(this).apply {
            text = value; textSize = size; setTextColor(color)
            gravity = Gravity.CENTER
            if (bold) typeface = Typeface.DEFAULT_BOLD
            setPadding(4, top, 4, bottom)
        }
        parent.addView(t, LinearLayout.LayoutParams(-1, -2))
    }

    private fun field(hint: String): EditText {
        return EditText(this).apply {
            this.hint = hint
            setHintTextColor(Color.LTGRAY)
            setTextColor(Color.WHITE)
            textSize = 16f
            inputType = 129
            setSingleLine(true)
            setPadding(18, 12, 18, 12)
            backgroundTintList = android.content.res.ColorStateList.valueOf(blue)
        }.also { root.addView(it, LinearLayout.LayoutParams(-1, -2).apply { bottomMargin = 14 }) }
    }

    private fun action(label: String, color: Int, onClick: () -> Unit) {
        val b = Button(this).apply {
            text = label; setTextColor(Color.WHITE); setBackgroundColor(color)
            isAllCaps = false; textSize = 16f; setOnClickListener { onClick() }
        }
        root.addView(b, LinearLayout.LayoutParams(-1, 52).apply { topMargin = 8; bottomMargin = 8 })
    }

    private fun showEntry() {
        shell()
        if (!prefs.contains("hash")) showSetup() else showLogin()
    }

    private fun showSetup() {
        root.removeAllViews()
        heading("ADMIN PASSWORD SETUP")
        addText(root, "First launch: create an admin password.", 14f, Color.LTGRAY)
        val p1 = field("Create password (minimum 6 characters)")
        val p2 = field("Confirm password")
        action("SAVE PASSWORD", red) {
            val a = p1.text.toString()
            val b = p2.text.toString()
            when {
                a.length < 6 -> toast("Password must be at least 6 characters")
                a != b -> toast("Passwords do not match")
                else -> {
                    savePassword(a)
                    toast("Admin password created")
                    showLogin()
                }
            }
        }
    }

    private fun showLogin() {
        root.removeAllViews()
        heading("SECURE LOGIN")
        addText(root, "Enter your password to continue", 14f, Color.LTGRAY)
        val pass = field("Password")
        action("LOGIN", blue) {
            if (verify(pass.text.toString())) showDashboard()
            else toast("Incorrect password")
        }
        addText(root, "Forgot password? Reinstalling the app resets local setup.", 11f, Color.GRAY)
    }

    private fun showDashboard() {
        root.removeAllViews()
        heading("DASHBOARD")
        addText(root, "Welcome to MUNIR X", 20f, Color.WHITE, true)
        addText(root, "Headshot Training • Sensitivity Guide • HUD Tips", 13f, Color.LTGRAY)
        action("HEADSHOT TRAINING", red) {
            showInfo("HEADSHOT TRAINING", "Practice tracking and controlled aim in the in-game training area. Focus on steady movement and accuracy.")
        }
        action("SENSITIVITY GUIDE", blue) {
            showInfo("SENSITIVITY GUIDE", "Use the in-game settings menu and adjust gradually. Test one change at a time and keep settings comfortable for your device.")
        }
        action("HUD SETTINGS", red) {
            showInfo("HUD SETTINGS", "Arrange controls for comfortable reach. Use the game's own HUD editor and test your layout in training.")
        }
        action("CHANGE ADMIN PASSWORD", blue) { showChangePassword() }
        action("LOG OUT", Color.DKGRAY) { showLogin() }
    }

    private fun showInfo(title: String, message: String) {
        root.removeAllViews()
        heading(title)
        addText(root, message, 16f, Color.WHITE)
        action("BACK", blue) { showDashboard() }
    }

    private fun showChangePassword() {
        root.removeAllViews()
        heading("CHANGE PASSWORD")
        val old = field("Current password")
        val p1 = field("New password (minimum 6 characters)")
        val p2 = field("Confirm new password")
        action("UPDATE PASSWORD", red) {
            val a = p1.text.toString()
            when {
                !verify(old.text.toString()) -> toast("Current password is incorrect")
                a.length < 6 -> toast("New password must be at least 6 characters")
                a != p2.text.toString() -> toast("New passwords do not match")
                else -> { savePassword(a); toast("Password updated"); showDashboard() }
            }
        }
        action("BACK", blue) { showDashboard() }
    }

    private fun savePassword(password: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        prefs.edit().putString("salt", salt.joinToString("") { "%02x".format(it) })
            .putString("hash", digest(salt, password)).apply()
    }

    private fun verify(password: String): Boolean {
        val saltHex = prefs.getString("salt", null) ?: return false
        val salt = saltHex.chunked(2).map { it.toInt(16).toByte() }.toByteArray()
        val expected = prefs.getString("hash", "") ?: ""
        return MessageDigest.isEqual(digest(salt, password).toByteArray(), expected.toByteArray())
    }

    private fun digest(salt: ByteArray, password: String): String =
        MessageDigest.getInstance("SHA-256").digest(salt + password.toByteArray())
            .joinToString("") { "%02x".format(it) }

    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
}
